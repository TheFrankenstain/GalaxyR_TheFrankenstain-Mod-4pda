<?php
/**
*  @fileOverview master/api/PlayFileMaster.js.         
*  @author Oleg Korniyenko, Volodymyr Zubariev
*  @version 1.0
*  @date Created 03.03.2011
*  @modified 16.06.2011 18:09:00
*  @param In Samsung Ukraine R&D Center (SURC) under a contract between
*  @param LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
*  @param Copyright:   Samsung Electronics Co, Ltd 2011. All rights reserved.
*/
//header('Content-type: ' . $_GET['format'] );
header( "Content-Length: ".filesize($_GET['filename']) );
@readfile($_GET['filename']);
?>
