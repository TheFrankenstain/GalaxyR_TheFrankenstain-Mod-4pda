<?php
/**
*  @fileOverview master/api/DownloadFileMaster.js.         
*  @author Sergey Kurstak
*  @version 1.0
*  @modified 16.06.2011 18:09:00
*  @param In Samsung Ukraine R&D Center (SURC) under a contract between
*  @param LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
*  @param Copyright:   Samsung Electronics Co, Ltd 2011. All rights reserved.
*/

/*
 * argument $contentDispotition must be "attachment" to download or "inline" to reproduce/view
 */
function send_file($path, $mtype, $cacheTime, $contentDispotition) {
	$stat = stat($path);
	if ($stat === FALSE) throw new Exception ("send_file - ". $path . " not accessible");
	$lastModifiedTimestamp = $stat['mtime'];
	$daterfc822 = date(DATE_RFC822,$lastModifiedTimestamp);
	$daterfc822Expiration = date(DATE_RFC822,time() + $cacheTime);
	if ($_SERVER["HTTP_IF_MODIFIED_SINCE"]==$daterfc822)
	{
		header("Status: 304");
		header("__Last-Modified: ".$daterfc822);
		exit();
	}
	header("Status: 200");
	header("Last-Modified: ".$daterfc822);
	header("Expires:".$daterfc822Expiration);
	header("Cache-Control: public, max-age=".$cacheTime);
	header( "X-Sendfile: ".$path);
	if (!$mtype) throw new Exception("mtype must not be null");
	header( "Content-Type: ". $mtype);
	header("Content-Length: ". $stat['size']);
	header( "Content-Disposition: ". $contentDispotition ."; filename=\"". str_replace('+',' ',urlencode(basename($path)) ) ."\"");
}
?>