<?php
/**
*  @fileOverview master/api/Controls/contacts/contactsList.php - PHP file that gives access to Contacts list to other applications.
*  @author Oleg Korniyenko
*  @version 1.0
*  @date Created 03.03.2011
*  @modified 16.06.2011 18:09:00
*  @param In Samsung Ukraine R&D Center (SURC) under a contract between
*  @param LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
*  @param Copyright:   Samsung Electronics Co, Ltd 2011. All rights reserved.
*/

include_once '../../../../../../php-common/phonebook/PhonebookWebService.php';
$phoneBook = new PhonebookWebService();

$searchString = strtolower($_GET['search']);
$eol = false;

$countWithPhone = 0;

$tryIndex = 0;
$result = array();
while (!$eol && $countWithPhone < 6) {

    $list = $phoneBook->search(trim($_GET['search']), SORT_NATURAL, $tryIndex*50, 50);

    if(count($list) == 0) break;

    $result = array();

    foreach ($list as $contact) {

	$phones = array();
	if($contact->homePhoneNo != "") {
	    $phones[] = $contact->homePhoneNo;
	}

	if($contact->mobilePhoneNo != "") {
	    $phones[] = $contact->mobilePhoneNo;
	}

	if($contact->workPhoneNo != "") {
	    $phones[] = $contact->workPhoneNo;
	}

	if($contact->otherPhoneNo != "") {
	    $phones[] = $contact->otherPhoneNo;
	}

	if(count($phones) == 0) continue;

	$countWithPhone++;

	$result[] = array(
	    "id"	=> $contact->id,
	    "name"	=> $contact->firstName . ' ' . $contact->lastName,
	    "phones"	=> $phones
	);

	if($countWithPhone >= 6) {
	    break;
	}

    }

    $tryIndex++;
    
}

if(count($result) == 0) {
    $result = array();
}

echo json_encode($result);
?>