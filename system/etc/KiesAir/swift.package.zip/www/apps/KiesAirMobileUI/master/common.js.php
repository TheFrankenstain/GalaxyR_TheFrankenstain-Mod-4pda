<?php
/**
*  @fileOverview master/common.js.php
*  @author Sergey Kurstak, Volodymyr Zubariev, Oleg Korniyenko, Shvetsov Artem
*  @version 1.0
*  @modified 25.08.2011 17:33:57
*  @param In Samsung Ukraine R&D Center (SURC) under a contract between
*  @param LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
*  @param Copyright:   Samsung Electronics Co, Ltd 2011. All rights reserved.
*/
?>

/**
 *  @class
 *  @description Contains screen width.
 *  @property {integer} width Last remembered screen width.
 */
var Screen = {
    oldWidth : 0,
    zoomRatio : 1.0
};


/**
 *  @function
 *  @description Launches on body load and manages the behaviour of the master control
 *  to keep the UI in place.
 */
scaleBody = function () {
        
        var body = document.getElementsByTagName("body")[0];
        Screen.zoomRatio = Math.round((window.innerWidth / window.outerWidth)*100)/100;
        body.style.zoom = Screen.zoomRatio*100 + "%"; 
}

scaleBody();

/**
 *  @function
 *  @description We register an event listener on body resize.
 */
window.addEventListener("resize", function () {
    scaleBody();
},false);


/** 
 *  @class
 *  @description Contains date parser.
 */
var DateParser = {
	/** 
	 *  @function
	 *  @description Parses unix timestamp date.
	 *  @param {integer} dt Unix timestamp.
	 *  @param {string} locale Locale ('en-GB' for example).
	 */        
       
	parseDate : function (dt) {		
		var d = new Date();
		d.setTime(parseInt(dt, 10) * 1000);
		var pastdate = d.getDate();
		var pastmonth = d.getMonth();
		var pasthours = d.getHours();
		var pastminutes = d.getMinutes();
		var ampm = "AM";
		
		if (pastdate < 10) {
			pastdate = "0" + pastdate;
		}
		
		pastmonth = pastmonth + 1;
		if (pastmonth < 10) {
			pastmonth = "0" + pastmonth;
		}
		
		if (pasthours >= 13) {
			pasthours = pasthours - 12;
			ampm = "PM";
		}
		
		if (pasthours < 10) {
			pasthours = "0" + pasthours;
		}		
		
		if (pastminutes < 10) {
			pastminutes = "0" + pastminutes;
		}	
		
		var cdate = new Date();
		var curdate = cdate.getDate();
		var diff = curdate - pastdate;
		
		var date = document.createElement("span");
                
		if (pastdate == curdate) {		
                    date = Widget.RegisterText("TODAY");
		}
		else if (diff == 1 || diff == -27 || diff == -28 || diff == -29 || diff == -30) {			
                    date = Widget.RegisterText("YESTERDAY");
		}
		else {
			var tmpspan = document.createElement("span");
                        tmpspan.innerHTML = pastmonth + "/" + pastdate  + "/" + d.getFullYear();
                        date = tmpspan;
		}		
		var time = document.createElement("span");
                time.innerHTML = " " + pasthours + ":" + pastminutes + " " + ampm;

                var result = document.createElement("span");
                result.appendChild(date);
                result.appendChild(time);
		return result;
	}
};