﻿<?php
 /*  @fileOverview modules/Locale/load_locale.php - Locale checker.
 *  Created in Samsung Ukraine R&D Center (SURC) under a contract between
 *  LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
 *  Copyright: Samsung Electronics Co, Ltd 2011. All rights reserved.
 *  @author Volodymyr Zubariev
 *  @version 1.0
 *  @date Created 03.03.2011
 *  @modified 25.08.2011 13:06:50
 */
    session_start();
	$Locale = "AUTO_DETECT";

    if(isset($_GET['LOCALE'])) {		
		$Locale  = $_GET['LOCALE'];
    } else if(isset($_SESSION['LOCALE'])) {
		$Locale  = $_SESSION['LOCALE'];
	}

	echo  "{LastLocale : '" . $Locale . "'," ;
    
	if(isset($_GET['LOCALE']) && isset($_GET['SET']) && $_GET['SET']) {
		$_SESSION['LOCALE'] = $Locale;
	} 

	if($Locale == "AUTO_DETECT") {
		$userLanguages = $_SERVER["HTTP_ACCEPT_LANGUAGE"];
                
                switch ($userLanguages) {
                    case "ha-HA" : {
                        $Locale = "hausa";
                        break;
                    }
                    case "en-PH" : {
                        $Locale = "en_ph";
                        break;
                    }
                    case "fr-CA" : {
                        $Locale = "fr_ca";
                        break;
                    }
                    case "es-US" : {
                        $Locale = "es_la";
                        break;
                    }
                    case "en-US" : {
                        $Locale = "en_us";
                        break;
                    }
                    case "ig-IG" : {
                        $Locale = "igbo";
                        break;
                    }
                    case "ga-GA" : {
                        $Locale = "irish";
                        break;
                    }
                    case "jv-JV" : {
                        $Locale = "javanese";
                        break;
                    }
                    case "pt-BR" : {
                        $Locale = "pt_la";
                        break;
                    }
                    case "yo-YO" : {
                        $Locale = "yoruba";
                        break;
                    }
                    case "zh-ZH" : {
                        $Locale = "zh_cn";
                        break;
                    }
                    case "zh-HK" : {
                        $Locale = "zh_hk";
                        break;
                    }
                    case "zh-SG" : {
                        $Locale = "zh_sg";
                        break;
                    }
                    case "zh-TW" : {
                        $Locale = "zh_tw";
                        break;
                    }
                    default : {
                        $firstLangCode = substr($userLanguages, 0, strpos($userLanguages, '-'));
                        $Locale = $firstLangCode;
                        break;
                    }
                }
	}

  echo ' SystemLocale : "'. $_SERVER["HTTP_ACCEPT_LANGUAGE"] .'",';
	echo ' CurrentLocale : "' . $Locale . '"}';
?>