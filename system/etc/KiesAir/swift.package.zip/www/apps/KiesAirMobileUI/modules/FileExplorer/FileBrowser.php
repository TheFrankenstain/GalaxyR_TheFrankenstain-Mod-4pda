<?php
/**
*  @fileOverview modules/FileExplorer/FileBrowser.php - Class for performing search of files on device.
*  @author Oleg Korniyenko
*  @version 1.0
*  @date Created 11.02.2011
*  @modified 08.07.2011 11:57:36
*  @param In Samsung Ukraine R&D Center (SURC) under a contract between
*  @param LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
*  @param Copyright:   Samsung Electronics Co, Ltd 2011. All rights reserved.
*/

/**
 * FileBrowser class
 *
 * @author O.Korniyenko
 */
class FileBrowser {

    private $startIndex;
    private $itemsPerPage;
    private $dirPath;
    private $totalResultsCount = 0;

    public function  __construct($dirPath, $itemsPerPage = 15, $startIndex = 0) {

	$this->itemsPerPage = $itemsPerPage;
	$this->startIndex = $startIndex;
	$this->dirPath = $dirPath;

    }

    public function getFiles() {

	$dirHandle = opendir($this->dirPath);

	$list = array();

	while(($file = readdir($dirHandle)) !== false) {

	    if($file != '.' && $file != '..' && substr($file, 0, 1) != '.' && is_dir($this->dirPath . '/' . $file)) {

                $fileName = $file;

                $list[] = array(
                    'name' => $fileName,
                    'type' => 'dir',
                    'parent' => $this->dirPath
                );

	    }

	}
	
	closedir($dirHandle);
	sort($list);

	$list1 = array();

	$dirHandle = opendir($this->dirPath);

	while(($file = readdir($dirHandle)) !== false) {

	    if($file != '.' && $file != '..' && substr($file, 0, 1) != '.' && !is_dir($this->dirPath . '/' . $file)) {
	        $list1[] = array(
                    'name' => $file,
                    'type' => 'file',
                    'parent' => $this->dirPath
                );
	    }

	}
	closedir($dirHandle);

	sort($list1);

	foreach ($list1 as $value) {
	    $list[] = $value;
	}

	$this->totalResultsCount = count($list);
	return $list;

    }

    public function getTotalResultsCount() {

	return $this->totalResultsCount;

    }

}
?>