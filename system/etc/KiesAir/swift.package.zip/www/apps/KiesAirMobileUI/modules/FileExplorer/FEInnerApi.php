<?php
/**
*  @fileOverview modules/FileExplorer/FEInnerApi.php.
*  @author Oleg Korniyenko
*  @version 1.0
*  @date Created 28.06.2011
*  @modified 29.06.2011 15:11:00
*  @param In Samsung Ukraine R&D Center (SURC) under a contract between
*  @param LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
*  @param Copyright:   Samsung Electronics Co, Ltd 2011. All rights reserved.
*/
include_once 'FileBrowser.php';

$dir = isset($_GET['dir']) ? $_GET['dir'] : '/sdcard';

$FileBrowser = new FileBrowser($dir);
$list = $FileBrowser->getFiles();

if(! $list) {
    $list = array();
}

echo json_encode($list);
?>