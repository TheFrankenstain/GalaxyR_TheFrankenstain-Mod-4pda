<?php
/**
*  @fileOverview modules/Upload/CheckFileExists.php
*  @author Oleg Korniyenko
*  @version 1.0
*  @date Created 08.02.2011
*  @modified 16.06.2011 18:09:00
*  @param In Samsung Ukraine R&D Center (SURC) under a contract between
*  @param LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
*  @param Copyright:   Samsung Electronics Co, Ltd 2011. All rights reserved.
*/
$filepath = $_GET['filepath'];

if(file_exists($filepath)) {
    echo 1;
}
?>