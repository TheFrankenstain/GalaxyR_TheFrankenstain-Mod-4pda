<?php
/**
*  @fileOverview modules/CallLogs/SmartSearch.php - Class for performing search in Call Logs.
*  @author Oleg Korniyenko
*  @version 1.0
*  @date Created 11.02.2011
*  @modified 8.07.2011 12:00:18
*  @param In Samsung Ukraine R&D Center (SURC) under a contract between
*  @param LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
*  @param Copyright:   Samsung Electronics Co, Ltd 2011. All rights reserved.
*/

/**
 * SmartSearch class
 *
 * @author O.Korniyenko
 */
class SmartSearch {

    private $searchQuery;
    private $searchType;
    private $startIndex;
    private $itemsPerPage;
    private $telephonyWS;
    private $totalResultsCount = 0;
    const ITEMS_BY_QUERY = 1000000;
    const SEARCH_API_QUERY   = 1;
    const SEARCH_API_TYPE = 2;
    const SEARCH_CUSTOM_QUERY  = 4;
    const SEARCH_CUSTOM_TYPE  = 8;

    public function  __construct($telephonyWS, $itemsPerPage = 15, $searchQuery = '', $searchType = '', $startIndex = 0) {

	$this->telephonyWS = $telephonyWS;
	$this->itemsPerPage = $itemsPerPage;
	$this->searchQuery = trim($searchQuery);

	if(strtolower($searchType) != 'all') {
	    $this->searchType = strtolower($searchType);
	}

	$this->startIndex = $startIndex;

    }

    public function getResults($offset = 0, $countAlreadyFound = 0) {

	$searchWay = 0;
	$searchString = '';
	if(substr($this->searchQuery,0,1) == '+' && is_numeric(substr($this->searchQuery,1))) {
	    // we got phone number here, that starts from a "+" - this is a search by a phone's beginning, API allows search like that, so we'll use it
	    $searchWay += self::SEARCH_API_QUERY;

	    if($this->searchType != '') {
		$searchWay += self::SEARCH_CUSTOM_TYPE;
	    }
	}
	else {
	    // ok, this is not a phone number with a "+" at the beginning - so it can be anything - part of a number, part of a name etc.
	    if($this->searchQuery != '') {
		$searchWay += self::SEARCH_CUSTOM_QUERY;
	    }

	    if($this->searchType != '') {
		$searchWay += self::SEARCH_API_TYPE;
	    }
	}

	if($searchWay & self::SEARCH_API_QUERY) {

	    $searchString = 'source:' . $this->searchQuery;

	}
	if($searchWay & self::SEARCH_API_TYPE) {

	    $searchString = 'flags:' . $this->searchType;

	}
	$list = $this->telephonyWS->search($this->startIndex + $offset, self::ITEMS_BY_QUERY, 'time-descending', $searchString);
	unset($list['size']);

	if(count($list) == 0) {
	    return array();
	}

/*
	if(!($searchWay & self::SEARCH_CUSTOM_QUERY) && !($searchWay & self::SEARCH_CUSTOM_TYPE)) {
	    $this->totalResultsCount = count($list);
//	    return array_slice($list, 0, $this->itemsPerPage);

	}
*/
	$unmatched = array();

	/*foreach ($list as $index => $call) {

	    if(array_search('sms-incoming', $call->flags) !== false || array_search('sms-outgoing', $call->flags) !== false) {

		$unmatched[] = $index;
	    
		
	    }
	    
	}*/

	if($searchWay & self::SEARCH_CUSTOM_QUERY) {

	    foreach ($list as $index => $call) {

		if(stripos($call->source, $this->searchQuery) === false &&
		    stripos($call->sourceName, $this->searchQuery) === false &&
		    stripos($call->destination, $this->searchQuery) === false &&
		    stripos($call->destinationName, $this->searchQuery) === false) {

			$unmatched[] = $index;
			continue;

		}

	    }

	}
	if($searchWay & self::SEARCH_CUSTOM_TYPE) {

	    foreach ($list as $index => $call) {

		if(array_search($this->searchType, $call->flags) === false) {

			$unmatched[] = $index;
			continue;

		}

	    }

	}

	foreach ($unmatched as $index) {

	    unset($list[$index]);

	}

	if(count($list) >= $this->itemsPerPage*5 - $countAlreadyFound) {
	    $this->totalResultsCount += count($list) + $this->startIndex;
	    return array_slice($list, 0, $this->itemsPerPage - $countAlreadyFound);

	}
	else {

	    $newList = $this->getResults($offset + self::ITEMS_BY_QUERY, count($list));
	    $this->totalResultsCount += count($newList) + count($list);
	    return array_merge($list, $newList);

	}

    }

    public function getTotalResultsCount() {

	return $this->totalResultsCount;

    }

}
?>