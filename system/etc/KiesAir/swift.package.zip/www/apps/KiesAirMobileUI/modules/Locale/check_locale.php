<?php
 /*  @fileOverview modules/Locale/check_locale.php - Locale checker.
 *  Created in Samsung Ukraine R&D Center (SURC) under a contract between
 *  LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
 *  Copyright: Samsung Electronics Co, Ltd 2011. All rights reserved.
 *  @author Sergey Kurstak
 *  @version 1.0
 *  @date Created 03.03.2011
 *  @modified 16.06.2011 18:09:00
 */
     session_start();

     if(isset($_GET['SET_LOCALE'])) {

        $_SESSION['LOCALE'] = $_GET['SET_LOCALE'];
     }
     else {
         $response = "";

         if (!isset($_SESSION['LOCALE'])){
	    $userLanguages = $_SERVER["HTTP_ACCEPT_LANGUAGE"];
	    $firstLangCode = substr($userLanguages, 0, 2);
            $response = $firstLangCode;
         }
         else {
            $response = $_SESSION['LOCALE'];
         }
         
         echo $response;
     }
?>