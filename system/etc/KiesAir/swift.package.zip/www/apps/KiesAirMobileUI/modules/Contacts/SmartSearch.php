<?php
/**
*  @fileOverview modules/Contacts/SmartSearch.php - Class for performing search in Contacts.
*  @author Oleg Korniyenko
*  @version 1.0
*  @date 11.02.2011
*  @modified 13.07.2011 16:58:52
*  @param In Samsung Ukraine R&D Center (SURC) under a contract between
*  @param LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
*  @param Copyright:   Samsung Electronics Co, Ltd 2011. All rights reserved.
*/

/**
 * SmartSearch class
 *
 * @author O.Korniyenko
 */
class SmartSearch {

    private $searchQuery;
    private $searchType;
    private $startIndex;
    private $itemsPerPage;
    private $phoneBookWS;
    private $sort;
    private $totalResultsCount = 0;
    const ITEMS_BY_QUERY = 100500;


    public function  __construct($phoneBookWS, $itemsPerPage = 15, $searchQuery = '', $searchType = '', $startIndex = 0, $sort='alpha-ascending') {

	$this->phoneBookWS = $phoneBookWS;
	$this->itemsPerPage = $itemsPerPage;
	$this->searchQuery = trim($searchQuery);
	$this->sort = $sort;

	if(strtolower($searchType) != 'all') {
	    $this->searchType = strtolower($searchType);
	}

	$this->startIndex = $startIndex;

    }

    public function getResults($offset = 0, $countAlreadyFound = 0) {

	$searchWay = 0;
	$searchString = '';

	if($this->searchType == 'favorites') {
	    $searchString = 'favourite:1';
            if($this->searchQuery != '') {
                $searchString .= ' ' . $this->searchQuery;
            }
	}
	else {
	    $searchString = $this->searchQuery;
	}

        $list = $this->phoneBookWS->search($searchString, $this->sort, $this->startIndex + $offset, self::ITEMS_BY_QUERY);

	$this->totalResultsCount =  $list['size'];

	unset($list['size']);

	if(count($list) == 0) {
	    return array();
	}

	return array_slice($list, 0, $this->itemsPerPage);


    }

    public function getTotalResultsCount() {

	return $this->totalResultsCount;

    }

}
?>