<?php
/**
*  @fileOverview modules/CallLogs/CallsInnerApi.php.
*  @author Oleg Korniyenko
*  @version 1.0
*  @date Created 07.02.2011
*  @modified 12.07.2011 17:56:53
*  @param In Samsung Ukraine R&D Center (SURC) under a contract between
*  @param LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
*  @param Copyright:   Samsung Electronics Co, Ltd 2011. All rights reserved.
*/
include_once '../../../../php-common/telephony/TelephonyWebService.php';
include_once 'SmartSearch.php';

$page = isset($_GET['page']) ? ($_GET['page'] > 0 ? $_GET['page'] : 1) : 1;
$telephony = new TelephonyWebService();

define('ITEMS_PER_PAGE', 100500);

$SmartSearch = new SmartSearch($telephony, ITEMS_PER_PAGE, @$_GET['search'], @$_GET['type'], ($page-1)*ITEMS_PER_PAGE);
$list['items'] = $SmartSearch->getResults();

$list['size'] = $SmartSearch->getTotalResultsCount();
/*
if(isset($_GET['count'])) {
    echo $size;
    die();
}
*/

if(!$list['items']) {
    $list['items'] = array();
}

if(!$list['size']) {
    $list['size'] = 0;
}

echo json_encode($list);
?>