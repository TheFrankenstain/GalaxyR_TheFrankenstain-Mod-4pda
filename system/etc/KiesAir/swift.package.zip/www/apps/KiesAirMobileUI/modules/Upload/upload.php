<?php
/**
*  @fileOverview modules/Upload/upload.php
*  @author Oleg Korniyenko
*  @version 1.0
*  @date Created 08.02.2011
*  @modified 16.06.2011 18:09:00
*  @param In Samsung Ukraine R&D Center (SURC) under a contract between
*  @param LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
*  @param Copyright:   Samsung Electronics Co, Ltd 2011. All rights reserved.
*/

// Work-around for setting up a session because Flash Player doesn't send the cookies
	if (isset($_POST["PHPSESSID"])) {
		session_id($_POST["PHPSESSID"]);
	}
	session_start();

	if (!isset($_FILES["Filedata"]) || !is_uploaded_file($_FILES["Filedata"]["tmp_name"]) || $_FILES["Filedata"]["error"] != 0) {
//	    trigger_error('EPIC FAIL');
	}
	else {

	    if(!is_dir($_GET['dir'])) {

		$pathParts = explode('/', $_GET['dir']);   
		$path = '/';
		foreach ($pathParts as $part) {
		    if(!is_dir($path . $part)) {
			mkdir($path . $part);
		    }
		    $path .= $part . '/';
		}

	    }
	    trigger_error('Dir: ' . $_GET['dir']);
	    move_uploaded_file($_FILES["Filedata"]["tmp_name"], $_GET['dir'] . '/' . $_FILES["Filedata"]["name"]);

	}


	
?>