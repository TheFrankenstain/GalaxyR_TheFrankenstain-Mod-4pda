<!--
    /**
     *  @fileOverview index.html - MobileUI entry point.
     *  Created in Samsung Ukraine R&D Center (SURC) under a contract between
     *  LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
     *  Copyright: Samsung Electronics Co, Ltd 2011. All rights reserved.
     *  @author Sergey Kurstak, Volodymyr Zubariev, Oleg Korniyenko, Shvetsov Artem
     *  @version 1.0
     *  @date Created 03.03.2011
     *  @modified 25.08.2011 17:33:57
     */
-->

<?php
    session_start();

    $translations = file_get_contents('master/localization/_jsoff.txt');
    $transArray = explode(';', $translations);

    $currentLang = $_SERVER["HTTP_ACCEPT_LANGUAGE"];
    $currentLang = substr($currentLang, 0, strpos($currentLang, '-'));

    $userTranslation = "Your browser has JavaScript disabled. Please go to 'Settings' and tick 'Enable Javascript'.";

    foreach ($transArray as $trans) {

        list($lang, $value) = explode(':', $trans);
        if($lang == $currentLang) {

            $userTranslation = $value;
            break;

        }

    }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Kies Air MobileUI</title>
    <meta HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8"/>

    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=1;"/>
    <?php
           
        if (isset($_SESSION['DETECTEDCLIENT'])) {
            if ($_SESSION['DETECTEDCLIENT'] == "PC" && !$_SESSION['dev_mode']) {
                header("Location: ../../apps/KiesAir/main.gz.htm");                
            } 
            else if ($_SESSION['DETECTEDCLIENT'] == "Mobile") {
                
                echo "
                <script type='text/javascript' language='javascript'>
                    
                    var SERVERROOT = 'http://" . $_SERVER['HTTP_HOST'] . "';

                    var Client = {};
                    Client.Name = detectBrowser('" . $_SERVER['HTTP_USER_AGENT'] . "');

                    function detectBrowser(ua) {	
                        var model = isSupportedModel(ua);
                        var resolution = isSupportedResolution(ua);
                        var popup = '';

                        if (ua.indexOf('Android 2.1') != -1) {
                            popup = 'POPUP_';
                        }        

                        if (!isAndroid(ua)) {
                            return 'BLOCK';
                        } 
                        else if (!isSamsungDevice(ua)) {
                            return 'POPUP_OTHER';
                        }
                        else {
                            if (model != 'UNKNOWNMODEL') {
                                return popup + model;
                            }
                            else {
                                if (resolution != 'OTHER') {
                                    return popup + resolution;
                                }
                                else {
                                    return 'OTHER';
                                }
                            }
                        }
                    }

                    function isAndroid (ua) {
                        if (ua.indexOf('Android') != -1) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    }

                    function isSupportedModel (ua) {
                        if (ua.indexOf('GT-I9000') != -1 || ua.indexOf('GT-I9001') != -1 || ua.indexOf('SHV-M250') != -1 || 
                            ua.indexOf('GT-I5800') != -1 || ua.indexOf('GT-I9100') != -1) {
                            return 'MOBILE';
                        } 
                        else if (ua.indexOf('SHW-M180') != -1 || ua.indexOf('GT-P1000') != -1 || ua.indexOf('SCH-I800') != -1 ||
                                 ua.indexOf('SGH-T849') != -1) {
                            return 'TAB';
                        }
                        else if (ua.indexOf('GT-P7510') != -1 || ua.indexOf('SHW-M300W') != -1) {
                            return 'P4P5';
                        }
                        else {
                            return 'UNKNOWNMODEL';
                        }
                    }

                    function isSupportedResolution (ua) {
                        var ow = window.outerWidth;
                        var oh = window.outerHeight;

                        if ((ow == 480 && oh == 762) || (ow == 800 && oh == 442)) {
                            return 'MOBILE';
                        } 
                        else if ((ow == 600 && oh == 986) || (ow == 1024 && oh == 600)) {
                            return 'TAB';
                        }
                        else if ((ow == 800 && oh == 1176) || (ow == 1280 && oh == 696)) {
                            return 'P4P5';
                        }
                        else {
                            if ((ow == 800 && oh == 1230) || (ow == 1280 && oh == 800)) {
                                Client.Type = 'Galaxy_Note';
                            }
                            return 'OTHER';
                        }
                    }

                    function isSamsungDevice (ua) {
                        if (ua.indexOf('SHW') != -1 || ua.indexOf('SHV') != -1 || ua.indexOf('SCH') != -1 ||
                            ua.indexOf('YP') != -1 || ua.indexOf('GT') != -1 || ua.indexOf('SGH') != -1 || ua.indexOf('SAMSUNG') != -1) {
                            return true;
                        } 
                        else {
                            return false;
                        }
                    }
                

                </script>";              
            }
            else {
                if (!$_SESSION['dev_mode']) {
                    header("Location: ../../switch.php");
                }
                else {
                    echo "
                    <script type='text/javascript' language='javascript'>

                        var SERVERROOT = 'http://" . $_SERVER['HTTP_HOST'] . "';
                        var Client = { Name : 'OTHER' }

                    </script>";  
                }
            }
        }
        else {
            if (!$_SESSION['dev_mode']) {
                // no session variable - back to switch
                header("Location: ../../switch.php");
            }
        }
?>

<script type="text/javascript" src="master/master.js"></script>
</head>
<body>
    <noscript><?php echo $userTranslation; ?>.</noscript>
</body>
</html>