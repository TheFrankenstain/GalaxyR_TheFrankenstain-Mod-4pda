<?php
exec("/system/bin/logcat -d -v threadtime",$rows);
$filter=$_GET["filter"];
?>

<html>
<body>

<?php
for($i = count($rows) -1 ; $i>=0 ; $i--)
{
	if (!$filter || strpos($rows[$i],$filter))
	{
		print $rows[$i]."<BR>";
	}
}
?>

</body>
</html>



