<?php

// PH
require_once("id3.php");

class Response {
	public $items;
	public $size;
	
	public function __construct($_items, $_size) {
		$this->items= $_items;
		$this->size = $_size;
	}

	public function toString(){
		
		return "$items - " . $this->$items . "size - " . $this->size; 
	}
}

function directory_list($directory_base_path)
{
    $result_list = array();
    $files_json = null;
    $total = 0;

    if (!$folder_handle = opendir($directory_base_path)) 
    {
        error_log(__FUNCTION__ . "Could not open directory at: $directory_base_path");
        return false;
    }
    else
    {
        while(false !== ($dir_name = readdir($folder_handle))) 
        {
			if(is_dir($directory_base_path . $dir_name . "/")) 
            {  
            	if(strcmp($dir_name, ".")!=0 && strcmp($dir_name, "..")!=0 && strcmp($dir_name[0], ".")!=0)
                {
                	$total++;
                    $result_list[] = $dir_name;
                }
            }
        }
        
        closedir($folder_handle);
        
        $response = new Response($result_list, $total);
        
        $response_json = json_encode($response); 
        
        return $response_json;
    }
}

// Disable caching of the current document:
function setHeaders($isETag, $isError, $eTag, $lastUpdated) 
{
	if($isError) 
	{
		header('Status: 404 Not Found');
	} 
	else if ($isETag) 
	{
		$eTag = md5($eTag . $lastUpdated);
		header('ETag: W/"' . $eTag . '"');
		header('Cache-Control: private, must-revalidate, max-age=0');
	} 
	else 
	{
		header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
		header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header('Pragma: no-cache');
	}
}

$directory_base_path = $_GET["base"];

$eTag = "";
$lastUpdated = 0;
$isError = false;
$useETag = false; 

$directory_base_path = rtrim($directory_base_path, "/") . "/";

if (!is_dir($directory_base_path))
{
	error_log(__FUNCTION__ . "File at: $directory_base_path is not a directory.");
	$isError = true;
}
else
{
 	$response = directory_list($directory_base_path, true);
}

setHeaders($useETag, $isError, $eTag, $lastUpdated);

echo ($response);
?>