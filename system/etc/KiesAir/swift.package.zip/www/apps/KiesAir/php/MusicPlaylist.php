<?php

//Disable caching of the current document:
header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header('Pragma: no-cache');

$fileName = 'KiesAirMusicPlaylist.ini';


function sanitizeString($inStr) {
	$outStr = "";
	for ($i=0; $i<strlen($inStr); $i++) {
		if ($inStr[$i] == "\\") {
			$i++;
		}
		$outStr .= $inStr[$i];
	}
	return $outStr;
}

function doAdd($songs) {
	global $fileName;

	if (!$handle = fopen($fileName, 'a')) {
        echo '{"status":"failure","error":"Cannot open file ('.$fileName.')"}';
        exit; 
	}

	foreach ($songs as $song) {
		$song = sanitizeString($song);
		$str = md5($song) . ":" . $song. "\n";
	 	if (fwrite($handle,$str) === FALSE) {
	        echo '{"status":"failure","error":"Cannot write to file ('.$fileName.')"}';
	       	exit;
	 	}
	}
    echo '{"status":"success"}';
	fclose($handle);
}

function doRemove($songs) {
	global $fileName;
	
	$songs_hashes = array();
	foreach ($songs as $song) {
		$song = sanitizeString($song);
		$songs_hashes[] = md5($song);
	}

	$lines = array();
	if (file_exists($fileName)) {
		$lines = file($fileName, FILE_SKIP_EMPTY_LINES);
		foreach ($lines as $i => $line) {
			$hash = substr($line, 0, strpos($line, ":"));
			if (in_array($hash, $songs_hashes)) {
				unset($lines[$i]);
			}
		}
	}
	
	if (!$handle = fopen($fileName, 'w')) {
        echo '{"status":"failure","error":"Cannot open file ('.$fileName.')"}';
        exit; 
	}

	foreach ($lines as $line) {
		if (fwrite($handle,$line) === FALSE) {
	        echo '{"status":"failure","error":"Cannot write to file ('.$fileName.')"}';
	       	exit;
	 	}
	}	
	echo '{"status":"success"}';
	fclose($handle);
}

function doGet() {
	global $fileName;

	if (!file_exists($fileName)) {
		echo ('[]');
	}
	
	$lines = file($fileName, FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES);
	$objs = array();
	foreach ($lines as $line) {
		$obj = substr($line, strpos($line, ":")+1);
		$objs[] = $obj;
	}
	echo ('['.implode(",", $objs).']');
}



switch ($_GET['method']) {
	case 'add':
		doAdd($_POST['songs']);
		break;
	
	case 'remove':
		doRemove($_POST['songs']);
		break;
	
	case 'get':
	default:
		doGet();
		break;
}

?>