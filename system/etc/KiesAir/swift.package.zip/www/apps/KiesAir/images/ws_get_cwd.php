<?php
/*
 * This web service will return the absolute path of the KiesAir image directory.
 * Kupesan Kulendiran
 */
$p = getcwd();

echo $p;

?>