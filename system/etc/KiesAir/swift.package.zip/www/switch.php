<?php
   /*  @fileOverview switch.php - Top-level index.
    *  Created in Samsung Ukraine R&D Center (SURC) under a contract between
    *  LLC "Samsung Electronics Ukraine Company" (Kiev Ukraine) and "Samsung Electronics Co", Ltd (Seuol, Republic of Korea)
    *  Copyright: Samsung Electronics Co, Ltd 2011. All rights reserved.
    *  @author Sergey Kurstak, Shvetsov Artem
    *  @version 1.0
    *  @date 19.04.2011
    */

    session_start();

    // $_SESSION['dev_mode'] = true;
    $_SESSION['dev_mode'] = false;
    $_SESSION['DETECTEDCLIENT'] = "0";

    // If SWIFT is accessed from localhost we don't allow that.
    if (($_SERVER["REMOTE_ADDR"] == "127.0.0.1" || $_SERVER["HTTP_HOST"] == "localhost:8080") && !$_SESSION['dev_mode']) {
        echo "Welcome to KiesAir. Please access it from a PC or another handset.";
        die();
    }

    function detectOS ($ua) {
        if (strpos($ua,"Windows") !== false && strpos($ua,"Windows Phone") == false) {
            // if it's Windows, but not Windows Phone 7
            return "Windows";
        }
        else if (strpos($ua,"Mac OS X") !== false && strpos($ua,"iPod") == false && strpos($ua,"iPhone") == false && strpos($ua,"iPad") == false) {
            // if it's a Mac, but not iPod or iPhone
            return "Mac";
        }
        else if (strpos($ua,"Linux") !== false && strpos($ua,"Android") == false) {
            // if it's Linux but not Android
            return "Linux";
        }
        else if (strpos($ua,"SunOS") !== false) {
            return "SunOS";
        }
        else if (strpos($ua,"AmigaOS") !== false) {
            return "AmigaOS";
        }
        else if (strpos($ua,"BSD") !== false) {
            return "BSD";
        }
        else if (strpos($ua,"DragonFly") !== false) {
            return "DragonFly";
        }
        else if (strpos($ua,"OpenSolaris") !== false) {
            return "OpenSolaris";
        }
        else if (strpos($ua,"CrOS") !== false) {
            return "CrOS";
        }
        else if (strpos($ua,"Android") !== false) {
            return "Android";
        }
        else if (strpos($ua,"Bada") !== false) {
            return "Bada";
        }
        else {
            return "Block";
        }
    }

    function detectBrowser($ua) {
        $os = detectOS($ua);

        if ($os == "Windows" || $os == "Mac" || $os == "Linux" ||
            $os == "SunOS" || $os == "BSD" || $os == "DragonFly" ||
            $os == "FreeBSD" || $os == "OpenSolaris" || $os == "CrOS" ||
            $os == "AmigaOS")  {
            // This is a PC or a Mac for sure (or an unknown incompatible client)
            return "PC";
        }
        else {
            return "Mobile";
        }
    }

    $client = detectBrowser($_SERVER['HTTP_USER_AGENT']);
    switch ($client) {
        case "PC" : {
            $_SESSION['DETECTEDCLIENT'] = "PC";
            if(!$_SESSION['dev_mode']) {
                header("Location: apps/KiesAir/main.gz.htm");
            }
            else {
                echo "<a href='apps/KiesAir/main.gz.htm'>PC</a><br/><a href='apps/KiesAirMobileUI/index.php'>Mobile</a>";
            }
            break;
        }
        case "Mobile" : {
             // Supported handset
            $_SESSION['DETECTEDCLIENT'] = "Mobile";
            header("Location: apps/KiesAirMobileUI/index.php");
            break;
        }
        default : {
            // Something very wrong happened here
            header("Location: apps/KiesAir/main.gz.htm");
            break;
        }
    }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="user-scalable=no, width=device-width, initial-scale = 1, maximum-scale = 1"/>
<title>KiesAir</title>

</head>
<body>
</body>
</html>
