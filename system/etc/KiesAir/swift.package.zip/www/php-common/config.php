<?php

// This file provides the variables 
// TARGET_BIN_PATH - where binary files are stores
// TARGET_TMP_PATH - where temporary files are stored
// TARGET_CONF_PATH - where configuration files are stored
// TARGET_ROOT_PATH - the top level folder of swift
// TARGET_LOG_PATH - where log files are stored
// Do not use anything else directly , as it is liable to break!

if (getenv("SWIFT_PLATFORM")=='LINUX_DEV')
{
	define('TARGET_BIN_PATH',getenv("SWIFT_BIN"));
	define('TARGET_TMP_PATH',getenv("SWIFT_TMP"));
	define('TARGET_CONF_PATH',getenv("SWIFT_CONF"));
	define('TARGET_ROOT_PATH',getenv("SWIFT_WWW"));
	define('TARGET_LOG_PATH',getenv("SWIFT_LOG"));
}
else
{
	// TODO - need to se it for LIMO - but dont know how to check if server is LIMO
	define('TARGET_BIN_PATH','/data/data/com.samsung.swift/files');
	define('TARGET_TMP_PATH',TARGET_BIN_PATH.'/tmp');
	define('TARGET_CONF_PATH',TARGET_BIN_PATH);
	define('TARGET_ROOT_PATH',TARGET_BIN_PATH);
	define('TARGET_LOG_PATH',TARGET_BIN_PATH.'/log');
}
?>