<?php
error_reporting(E_ALL);
require_once dirname(__FILE__).'/../api_call.php';
require_once dirname(__FILE__).'/../utils/send_file.php';
require_once dirname(__FILE__).'/../utils/agent.php';
require_once dirname(__FILE__).'/../config.php';

define('SORT_NATURAL', 'natural');
define('SORT_LASTFIRST', 'alpha-descending');
define('SORT_FIRSTLAST', 'alpha-ascending');
define('SORT_ID_DES', 'id-descending');
define('SORT_ID_ASC', 'id-ascending');
define('START_INDEX', '0');
define('MAX_ITEMS', '50');

class Contact
{
    public $id;
    public $title;
    public $firstName;
    public $lastName;
    public $suffix;
    public $homePhoneNo;
    public $mobilePhoneNo;
    public $workPhoneNo;
    public $otherPhoneNo;
    public $defaultPhoneNo;
    public $homeEmail;
    public $workEmail;
    public $otherEmail;
    public $nickName;
    public $note;
    public $favourite;
    public $organisation;
    public $jobTitle;
    public $faxPhoneNo;
    public $pagerPhoneNo;
    public $businessAddress; 
    public $homeAddress;  
    public $logoPath;
    public $hasLogo;
    public $account;

    function __construct() {

    	$this->homeAddress = null;

    	$this->businessAddress = null;
    	
    	$this->account = null;
    }
    
    
    public function getContactLogoUri()
    {
    	if ($this->hasLogo)
    	{
	    	return '/ws/pim/contacts/'.$this->id.'/logo';
	    }
	    throw new Exception("has no logo");
    }   
}

class Address
{
   public $street;
   public $city;
   public $state;
   public $zipCode;
   public $country;

}

class Capabilities
{
   public $logoWidth;
   public $logoHeight;
   public $logoMimeType;
   public $simFields;
}

class Account
{
   public $type;
   public $name;
}

class PhonebookWebService extends ApiCall{
    public $selectedcontact;
    public $webservices_url;
    public $capabilities_url;
    public $accounts_url;

	function __construct() {
    	parent::__construct();
    	$this->webservices_url = 'http://'. '127.0.0.1:'.$_SERVER['SERVER_PORT'] .'/ws/pim/contacts';
    	$this->capabilities_url = 'http://'. '127.0.0.1:'.$_SERVER['SERVER_PORT'] .'/ws/pim/capabilities';
		$this->accounts_url = 'http://'. '127.0.0.1:'.$_SERVER['SERVER_PORT'] .'/ws/pim/accounts';
    }

    public function getAccounts() 
    {
		$arrResponse = $this->wsCall($this->accounts_url, 'GET');
    	$obj = $arrResponse['content'];

		$accountList=array();

	    foreach($obj->items as $var) 
		{
			$account=new Account();
			$account->type=$var->type;
			$account->name=$var->name;
	
			$accountList[] = $account;
		}
		
		return $accountList;
    }
    
    public function getList($sortType=SORT_NATURAL, $startIndex=START_INDEX, $maxItems=MAX_ITEMS) {
        $params = array('sort' => $sortType, 
						'startIndex' => $startIndex, 
						'maxItems' => $maxItems );
						
		$opts['timeout']=10;
        $arrResponse = $this->wsCall($this->webservices_url, 'GET', $params, $opts);
        $obj = $arrResponse['content'];

        $contactsList=array();
        foreach($obj->items as $var) {
        		$contact=new Contact();
        		$contact->id=$var->id;
        		$contact->title=$var->title;
        		$contact->firstName=$var->firstName;
        		$contact->lastName=$var->lastName;
        		$contact->suffix=$var->suffix;
        		$contact->nickName=$var->nickName;
        		$contact->organisation=$var->organisation;
        		$contact->jobTitle=$var->jobTitle;
        		$contact->homePhoneNo = $var->homePhoneNo;
        		$contact->mobilePhoneNo = $var->mobilePhoneNo;
        		$contact->workPhoneNo = $var->workPhoneNo;
        		$contact->otherPhoneNo = $var->otherPhoneNo;
        		$contact->defaultPhoneNo = $var->defaultPhoneNo;
        		$contact->faxPhoneNo = $var->faxPhoneNo;
        		$contact->pagerPhoneNo = $var->pagerPhoneNo;
        		$contact->homeEmail = $var->homeEmail;
            	$contact->workEmail = $var->workEmail;
        		$contact->otherEmail = $var->otherEmail;
        		$contact->note = $var->note;
				$contact->homeAddress = new Address();
        		$contact->homeAddress->street = $var->homePostalAddress->street;
        		$contact->homeAddress->city = $var->homePostalAddress->city;
        		$contact->homeAddress->state = $var->homePostalAddress->state;
        		$contact->homeAddress->zipCode = $var->homePostalAddress->zipCode;
        		$contact->homeAddress->country = $var->homePostalAddress->country;
				$contact->businessAddress = new Address();
        		$contact->businessAddress->street = $var->businessPostalAddress->street;
        		$contact->businessAddress->city = $var->businessPostalAddress->city;
        		$contact->businessAddress->state = $var->businessPostalAddress->state;
        		$contact->businessAddress->zipCode = $var->businessPostalAddress->zipCode;
        		$contact->businessAddress->country = $var->businessPostalAddress->country;        		
        		$contact->favourite = $var->favourite;
        		$contact->hasLogo = $var->hasLogo;
				$contact->account = new Account();
        		$contact->account->type = $var->accountType;
        		$contact->account->name = $var->accountName;
        		$contactsList[]=$contact;
        }
        return $contactsList;

    }
    
    public function backupContactList($fileName) {

		error_log('Backup');

		header("Content-Disposition: attachment; filename=".$fileName);
		header("Content-Type: text/csv; charset=utf-8");
		header("Status: 200");

	    $http = array(
        	'ignore_errors' => false,
            'method'=> 'GET',
        	'timeout' => 1,
			'header' => 'Accept: text/csv'
			);
		$opts = array('http' => $http);		
		$context = stream_context_create($opts);

		$currentIndex = 0;
		$pageSize = 2;

		while(true)
		{			
			$url = $this->webservices_url.'?startIndex='.$currentIndex.'&maxItems='.$pageSize;
			error_log($url);
			$h = FALSE;
			for ( $i = 0 ; $h==FALSE && $i<10 ; $i++)
			{
				error_log($i);
 				$h = fopen($url,'rb',false,$context);
			}
			if ($h==FALSE)
			{
				print "Error incomplete file";
				return;
			}
			# skip header line
			if ($currentIndex!=0)
			{
			 	error_log(fgets($h));
			 	print "\r\n";
			}
			$bytes = fpassthru($h);
			
			#$data = fread($h,8192);
			#$bytes = strlen($data);
			error_log($data);
			
			error_log($bytes);
			fclose($h);
			if ($bytes == 0)
			{
				break;
			}
			
			$currentIndex += $pageSize;
		}
		error_log('Done');
    }    

    public function get($id) {
   		$arrResponse = $this->wsCall($this->webservices_url.'/'.$id, 'GET');
    	$obj = $arrResponse['content'];

        $contact=new Contact();
        $contact->id=$obj->id;
        $contact->title=$obj->title;
        $contact->firstName=$obj->firstName;
        $contact->lastName=$obj->lastName;
        $contact->suffix=$obj->suffix;
        $contact->nickName=$obj->nickName;
        $contact->organisation=$obj->organisation;
        $contact->jobTitle=$obj->jobTitle;        
        $contact->homePhoneNo = $obj->homePhoneNo;
		$contact->mobilePhoneNo = $obj->mobilePhoneNo;
		$contact->workPhoneNo = $obj->workPhoneNo;
		$contact->otherPhoneNo = $obj->otherPhoneNo;
		$contact->defaultPhoneNo = $obj->defaultPhoneNo;
        $contact->faxPhoneNo = $obj->faxPhoneNo;
        $contact->pagerPhoneNo = $obj->pagerPhoneNo;		
		$contact->homeEmail = $obj->homeEmail;
        $contact->workEmail = $obj->workEmail;
        $contact->otherEmail = $obj->otherEmail;
        $contact->note = $obj->note;
		$contact->homeAddress = new Address();
        $contact->homeAddress->street = $obj->homePostalAddress->street;
		$contact->homeAddress->city = $obj->homePostalAddress->city;
		$contact->homeAddress->state = $obj->homePostalAddress->state;
		$contact->homeAddress->zipCode = $obj->homePostalAddress->zipCode;
		$contact->homeAddress->country = $obj->homePostalAddress->country;
		$contact->businessAddress = new Address();
		$contact->businessAddress->street = $obj->businessPostalAddress->street;
		$contact->businessAddress->city = $obj->businessPostalAddress->city;
		$contact->businessAddress->state = $obj->businessPostalAddress->state;
		$contact->businessAddress->zipCode = $obj->businessPostalAddress->zipCode;
		$contact->businessAddress->country = $obj->businessPostalAddress->country;         		
		$contact->favourite = $obj->favourite;
		$contact->hasLogo = $obj->hasLogo;
		$contact->account = new Account();
		$contact->account->name = $obj->accountName;
		$contact->account->type = $obj->accountType;
        $this->selectedcontact=$contact;
        return $contact;
    }
    
    public function backupContact($id, $filename) {
		
		error_log('Backup');

		header("Content-Disposition: attachment; filename=".$filename);
		header("Content-Type: text/x-vcard; charset=utf-8");
		header("Status: 200");

	    $http = array(
        	'ignore_errors' => false,
            'method'=> 'GET',
        	'timeout' => 1,
			'header' => 'Accept: text/x-vcard'
			);
		$opts = array('http' => $http);		
		$context = stream_context_create($opts);

		$url = $this->webservices_url.'/'.$id;
		error_log($url);

		$h = FALSE;
		for ( $i = 0 ; $h==FALSE && $i<10 ; $i++)
		{
			error_log($i);
			$h = fopen($url,'rb',false,$context);
		}
		if ($h==FALSE)
		{
			print "Error incomplete file";
			return;
		}

		$bytes = fpassthru($h);
			
		error_log($data);
		
		error_log($bytes);
		fclose($h);
		if ($bytes == 0)
		{
			break;
		}
		
		error_log('Done');
    }    

    public function edit($contact) {
		$params = array('title' => $contact->title,
						'firstName' => $contact->firstName,
			            'lastName' => $contact->lastName,
			            'suffix' => $contact->suffix,
			            'nickName' => $contact->nickName,
        				'organisation' => $contact->organisation,
        				'jobTitle' => $contact->jobTitle,    		
			            'mobilePhoneNo'=>$contact->mobilePhoneNo,
			            'workPhoneNo'=>$contact->workPhoneNo,
			            'homePhoneNo'=>$contact->homePhoneNo,
			            'otherPhoneNo'=>$contact->otherPhoneNo,
			            'defaultPhoneNo'=>$contact->defaultPhoneNo,
        				'faxPhoneNo'=>$contact->faxPhoneNo,
        				'pagerPhoneNo'=>$contact->pagerPhoneNo,	
			            'homeEmail'=>$contact->homeEmail,
			            'workEmail'=>$contact->workEmail,
			            'otherEmail'=>$contact->otherEmail,
			            'note' => $contact->note,
			            'home.street' => $contact->homeAddress->street,
			            'home.city' => $contact->homeAddress->city,
			            'home.state' => $contact->homeAddress->state,
			            'home.zipCode' => $contact->homeAddress->zipCode,
			            'home.country' => $contact->homeAddress->country,
        				'business.street' => $contact->businessAddress->street,
        				'business.city' => $contact->businessAddress->city,
        				'business.state' => $contact->businessAddress->state,
        				'business.zipCode' => $contact->businessAddress->zipCode,
        				'business.country' => $contact->businessAddress->country,		
			            'favourite' => $contact->favourite? 'true' : 'false',
			            'hasLogo' => $contact->hasLogo? 'true' : 'false',
 			            'logoPath' => $contact->logoPath,
 			            'accountType' => $contact->account->type,
 			            'accountName' => $contact->account-name
 			            );
        $this->wsCall($this->webservices_url.'/'.$contact->id, 'PUT', $params);
    }

    public function create($contact) {
        $params = array('title' => $contact->title,
						'firstName' => $contact->firstName,
			            'lastName' => $contact->lastName,
			            'suffix' => $contact->suffix,
			            'nickName' => $contact->nickName,
        				'organisation' => $contact->organisation,
        				'jobTitle' => $contact->jobTitle,         
			            'mobilePhoneNo'=>$contact->mobilePhoneNo,
			            'workPhoneNo'=>$contact->workPhoneNo,
			            'homePhoneNo'=>$contact->homePhoneNo,
			            'otherPhoneNo'=>$contact->otherPhoneNo,
			            'defaultPhoneNo'=>$contact->defaultPhoneNo,
        				'faxPhoneNo'=>$contact->faxPhoneNo,
        				'pagerPhoneNo'=>$contact->pagerPhoneNo,	        
			            //'workEmail'=>$contact->workEmail,
			            'workEmail[0]'=>"a@b.com",
        				'workEmail[1]'=>"c@d.com",
			            'homeEmail'=>$contact->homeEmail,
			            'otherEmail'=>$contact->otherEmail,
			            'note' => $contact->note,
			            'home.street' => $contact->homeAddress->street,
			            'home.city' => $contact->homeAddress->city,
			            'home.state' => $contact->homeAddress->state,
			            'home.zipCode' => $contact->homeAddress->zipCode,
			            'home.country' => $contact->homeAddress->country,
        				'business.street' => $contact->businessAddress->street,
        				'business.city' => $contact->businessAddress->city,
        				'business.state' => $contact->businessAddress->state,
        				'business.zipCode' => $contact->businessAddress->zipCode,
        				'business.country' => $contact->businessAddress->country,         
						'favourite' => $contact->favourite? 'true' : 'false',
			            'hasLogo' => $contact->hasLogo? 'true' : 'false',
 			            'logoPath' => $contact->logoPath,
 			            'accountType' => $contact->account->type,
 			            'accountName' => $contact->account->name					
						);
		$arrResponse = $this->wsCall($this->webservices_url, 'POST', $params);
		$location = $arrResponse['headers']['location'];
        return substr($location, strrpos($location, '/')+1); // pase the new {id} from: Location:/ws/pim/contacts/{id}
    }

    public function delete($ids) {
        if(is_array($ids)) {
            foreach($ids as $id) {
                $this->deleteSingleItem($id);
            }
        }else {
            $this->deleteSingleItem($ids);
        }
    }
    
    public function getCapabilities()
    {
        $arrResponse = $this->wsCall($this->capabilities_url, 'GET', null);
        $obj = $arrResponse['content'];
        
        $capabilities = new Capabilities();
        
        $capabilities->logoWidth = $obj->logoWidth;
	    $capabilities->logoHeight = $obj->logoHeight;
	    $capabilities->logoMimeType = $obj->logoMimeType;
	    
	    $capabilities->simFields = array();
	    
	    $capabilities->simFields = $obj->simFields;
	    
	    return $capabilities;
    }
    
    private function deleteSingleItem($id) {
        $arrResponse = $this->wsCall($this->webservices_url.'/'.$id, 'DELETE');
    }

    public function search($searchString, $sortType=SORT_NATURAL, $startIndex=START_INDEX, $maxItems=MAX_ITEMS) {
		$params = array('sort' => $sortType,
        				'startIndex' => $startIndex,
        				'maxItems' => $maxItems,
        				'searchQuery' => $searchString );
        $arrResponse = $this->wsCall($this->webservices_url, 'GET', $params);
        $obj = $arrResponse['content'];
        
        $contactsList=array();
        foreach($obj->items as $var) {
        	$contact=new Contact();
        	$contact->id			= $var->id;
        	$contact->title			= $var->title;
        	$contact->firstName		= $var->firstName;
        	$contact->lastName		= $var->lastName;
        	$contact->suffix		= $var->suffix;
        	$contact->nickName		= $var->nickName;
        	$contact->organisation	= $var->organisation;
			$contact->jobTitle		= $var->jobTitle;             	
        	$contact->mobilePhoneNo	= $var->mobilePhoneNo;
        	$contact->homePhoneNo 	= $var->homePhoneNo;
        	$contact->workPhoneNo 	= $var->workPhoneNo;
			$contact->otherPhoneNo 	= $var->otherPhoneNo;
			$contact->defaultPhoneNo = $var->defaultPhoneNo;
        	$contact->faxPhoneNo	= $var->faxPhoneNo;
        	$contact->pagerPhoneNo  = $var->pagerPhoneNo;				
        	$contact->workEmail		= $var->workEmail;        	               			
			$contact->homeEmail 	= $var->homeEmail;
	        $contact->otherEmail 	= $var->otherEmail;
	        $contact->note 			= $var->note;
			$contact->homeAddress = new Address();
	        $contact->homeAddress->street = $var->homePostalAddress->street;
			$contact->homeAddress->city = $var->homePostalAddress->city;
			$contact->homeAddress->state = $var->homePostalAddress->state;
			$contact->homeAddress->zipCode = $var->homePostalAddress->zipCode;
			$contact->homeAddress->country = $var->homePostalAddress->country;
			$contact->businessAddress = new Address();
			$contact->businessAddress->street = $var->businessPostalAddress->street;
			$contact->businessAddress->city = $var->businessPostalAddress->city;
			$contact->businessAddress->state = $var->businessPostalAddress->state;
			$contact->businessAddress->zipCode = $var->businessPostalAddress->zipCode;
			$contact->businessAddress->country = $var->businessPostalAddress->country;    			
			$contact->favourite 	= $var->favourite;
			$contact->hasLogo 	    = $var->hasLogo;
			$contact->account = new Account();
			$contact->account->type	= $var->accountType;
			$contact->account->name = $var->accountName;
        	$contactsList[]=$contact;
                $contactsList['size'] = $arrResponse['content']->size;
        }
        return $contactsList;
    }
}
?>